﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.UserManuals.Models
{
    public class UserManualListModel : BasePagedListModel<UserManualModel>
    {
    }
}
