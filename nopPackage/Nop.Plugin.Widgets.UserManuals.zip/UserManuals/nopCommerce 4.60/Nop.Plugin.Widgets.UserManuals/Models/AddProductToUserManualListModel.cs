﻿using Nop.Web.Areas.Admin.Models.Catalog;
using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.UserManuals.Models
{
    public partial record AddProductToUserManualListModel : BasePagedListModel<ProductModel>
    {
    }
}
