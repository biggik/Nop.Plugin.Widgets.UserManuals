﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.UserManuals.Models
{
    public class CategoryListModel : BasePagedListModel<CategoryModel>
    {
    }
}
