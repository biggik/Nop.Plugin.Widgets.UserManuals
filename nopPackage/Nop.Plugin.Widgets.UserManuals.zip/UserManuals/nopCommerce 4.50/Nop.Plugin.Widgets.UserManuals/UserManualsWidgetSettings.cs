﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.UserManuals
{
    public class UserManualsWidgetSettings : ISettings
    {
        public string WidgetZones { get; set; }
    }
}
